# ZypeHost Pterodactyl Theme v4

Dieses Theme baut die Pterodactyl-Loginseite im Stil des bereitgestellten Referenzbildes um:

- digitales Grid-Hintergrundbild statt blauem Standard-Hintergrund
- weiße Login-Karte
- ZypeHost-Logo links
- Loginformular rechts
- blauer LOGIN-Button
- „FORGOT PASSWORD?“
- Footer-Buttons „Impressum“ und „Rechte“
- Klick auf die Buttons öffnet ein eigenes Modal
- „Copyright ZypeHost 26/27 ©️“ ganz unten
- bestehende Pterodactyl-Authentifizierung bleibt erhalten

## Impressum bearbeiten

Öffne:

`theme/public/themes/zypehost/branding.js`

und ersetze die Platzhalter in `LEGAL.impressum` durch deine echten Angaben.

## Installation auf dem Pterodactyl-Server

Wenn die ZIP-Datei nach `/root` hochgeladen wurde:

```bash
cd /root
unzip -o ZypeHost-Pterodactyl-Theme-v4.zip
cd /root/ZypeHost-Pterodactyl-Theme-v4
chmod +x install.sh
bash install.sh
```

Falls Pterodactyl nicht unter `/var/www/pterodactyl` liegt:

```bash
PTERODACTYL_DIR=/DEIN/PFAD bash install.sh
```

## GitHub

Das komplette Paket kann direkt als Repository hochgeladen werden. Die `install.sh` ist für das Installieren auf einem Pterodactyl-Host gedacht.

## Deinstallation

```bash
cd /root/ZypeHost-Pterodactyl-Theme-v4
chmod +x uninstall.sh
bash uninstall.sh
```
