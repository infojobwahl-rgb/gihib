#!/usr/bin/env bash
set -Eeuo pipefail
PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
THEME_DIR="$PANEL_DIR/public/themes/zypehost"

if [[ -f "$WRAPPER" ]]; then
  python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import sys
import re
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r'<!-- ZYPEHOST_V4_ASSETS -->.*?<!-- /ZYPEHOST_V4_ASSETS -->\n?', '', s, flags=re.S)
p.write_text(s, encoding='utf-8')
PY
fi
rm -rf "$THEME_DIR"
cd "$PANEL_DIR"
php artisan optimize:clear >/dev/null 2>&1 || true
printf '%s\n' 'ZypeHost Theme v4 entfernt.'
