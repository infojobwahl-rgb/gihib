(() => {
  'use strict';

  const BRAND = 'ZypeHost';
  const LOGO = '/themes/zypehost/zypehost.svg';
  const BACKGROUND = '/themes/zypehost/background.jpeg';

  const LEGAL = {
    impressum: {
      title: 'Impressum',
      html: `
        <h3>ZypeHost</h3>
        <p><strong>Betreiber:</strong><br>HIER DEINEN NAMEN / FIRMA EINTRAGEN</p>
        <p><strong>Adresse:</strong><br>HIER STRASSE, PLZ UND ORT EINTRAGEN</p>
        <p><strong>E-Mail:</strong><br>HIER E-MAIL-ADRESSE EINTRAGEN</p>
        <p>Diese Angaben kannst du direkt in <code>branding.js</code> anpassen.</p>
      `
    },
    rechte: {
      title: 'Rechte',
      html: `
        <h3>ZypeHost</h3>
        <p>© ZypeHost 26/27. Alle Rechte an eigenen Marken, Grafiken und Inhalten bleiben beim jeweiligen Rechteinhaber.</p>
        <p>Pterodactyl ist ein eigenständiges Open-Source-Projekt. Dieses Theme verändert die Darstellung und das Branding der Oberfläche.</p>
        <p>Logos, Bilder und Drittanbieter-Inhalte dürfen nur entsprechend ihrer jeweiligen Lizenz bzw. mit der erforderlichen Erlaubnis verwendet werden.</p>
      `
    }
  };

  function createLegalModal() {
    if (document.querySelector('.zh-legal-overlay')) return;

    const overlay = document.createElement('div');
    overlay.className = 'zh-legal-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    overlay.innerHTML = `
      <div class="zh-legal-modal" role="dialog" aria-modal="true" aria-labelledby="zh-legal-title">
        <div class="zh-legal-header">
          <h2 id="zh-legal-title"></h2>
          <button type="button" class="zh-legal-close" aria-label="Schließen">×</button>
        </div>
        <div class="zh-legal-body"></div>
      </div>
    `;

    const close = () => {
      overlay.classList.remove('is-open');
      overlay.setAttribute('aria-hidden', 'true');
    };

    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) close();
    });
    overlay.querySelector('.zh-legal-close').addEventListener('click', close);
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') close();
    });

    overlay._open = (key) => {
      const data = LEGAL[key];
      if (!data) return;
      overlay.querySelector('#zh-legal-title').textContent = data.title;
      overlay.querySelector('.zh-legal-body').innerHTML = data.html;
      overlay.classList.add('is-open');
      overlay.setAttribute('aria-hidden', 'false');
    };

    document.body.appendChild(overlay);
  }

  function addLoginLayout() {
    if (!location.pathname.startsWith('/auth')) return;
    document.body.classList.add('zypehost-auth');
    document.body.style.setProperty('--zh-background', `url("${BACKGROUND}")`);

    const form = document.querySelector('form');
    if (!form) return;

    let host = form.parentElement;
    if (!host) return;

    if (!host.classList.contains('zh-login-card')) {
      const card = document.createElement('div');
      card.className = 'zh-login-card';
      const shellParent = host.parentElement || host;

      shellParent.insertBefore(card, host);
      card.appendChild(host);
      host.classList.add('zh-login-grid');
    }

    host = form.parentElement;
    if (!host.classList.contains('zh-login-grid')) host.classList.add('zh-login-grid');

    if (!host.querySelector('.zh-login-logo-pane')) {
      const logoPane = document.createElement('div');
      logoPane.className = 'zh-login-logo-pane';
      logoPane.innerHTML = `<img class="zh-login-logo" src="${LOGO}" alt="ZypeHost">`;
      host.insertBefore(logoPane, host.firstChild);
    }

    if (!host.querySelector('.zh-login-form-pane')) {
      const formPane = document.createElement('div');
      formPane.className = 'zh-login-form-pane';
      form.parentNode.insertBefore(formPane, form);
      formPane.appendChild(form);
    }

    const title = document.querySelector('h1, h2, .title, .text-center') || null;
    if (title && !title.classList.contains('zh-login-title') && /login|continue/i.test(title.textContent || '')) {
      title.classList.add('zh-login-title');
      title.textContent = 'Login to Continue';
    }

    const button = form.querySelector('button[type="submit"], button');
    if (button) {
      button.classList.add('zh-login-button');
      if (!button.textContent.trim()) button.textContent = 'LOGIN';
    }

    const forgot = Array.from(document.querySelectorAll('a')).find(a => /forgot password/i.test(a.textContent || ''));
    if (forgot) {
      forgot.textContent = 'FORGOT PASSWORD?';
      forgot.classList.add('zh-forgot-link');
      if (!forgot.parentElement.classList.contains('zh-forgot-wrap')) {
        const wrap = document.createElement('div');
        wrap.className = 'zh-forgot-wrap';
        forgot.parentElement.insertBefore(wrap, forgot);
        wrap.appendChild(forgot);
      }
    }
  }

  function replaceBrandText() {
    const replacements = new Map([
      ['Pterodactyl Software', BRAND],
      ['Pterodactyl Panel', BRAND],
      ['Pterodactyl', BRAND]
    ]);

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    const nodes = [];
    let node;
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      if (parent && !['SCRIPT', 'STYLE', 'CODE', 'PRE', 'TEXTAREA'].includes(parent.tagName)) nodes.push(node);
    }

    for (const textNode of nodes) {
      let value = textNode.nodeValue || '';
      for (const [from, to] of replacements) value = value.split(from).join(to);
      textNode.nodeValue = value;
    }
  }

  function addFooter() {
    let footer = document.querySelector('.zh-footer');
    if (!footer) {
      footer = document.createElement('footer');
      footer.className = 'zh-footer';
      document.body.appendChild(footer);
    }

    footer.innerHTML = `
      <div class="zh-footer-buttons">
        <button type="button" class="zh-footer-button" data-zh-legal="impressum">Impressum</button>
        <button type="button" class="zh-footer-button" data-zh-legal="rechte">Rechte</button>
      </div>
      <div class="zh-footer-copy">Copyright ZypeHost 26/27 ©️</div>
    `;

    createLegalModal();
    footer.querySelectorAll('[data-zh-legal]').forEach((button) => {
      if (button.dataset.zhBound === '1') return;
      button.dataset.zhBound = '1';
      button.addEventListener('click', () => {
        document.querySelector('.zh-legal-overlay')._open(button.dataset.zhLegal);
      });
    });
  }

  function run() {
    if (!document.body) return;
    document.title = BRAND;
    replaceBrandText();
    addLoginLayout();
    addFooter();
  }

  let ticking = false;
  function schedule() {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      ticking = false;
      run();
    });
  }

  function boot() {
    run();
    const observer = new MutationObserver(schedule);
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
