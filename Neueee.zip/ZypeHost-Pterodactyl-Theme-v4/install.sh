#!/usr/bin/env bash
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="$ROOT_DIR/theme/public/themes/zypehost"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$PANEL_DIR/storage/zypehost-backups/v4-$STAMP"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"

fail(){ echo "[ZypeHost v4] ERROR: $*" >&2; exit 1; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"
[[ -f "$WRAPPER" ]] || fail "wrapper.blade.php nicht gefunden: $WRAPPER"
[[ -f "$SRC/background.jpeg" ]] || fail "background.jpeg fehlt im Theme-Paket"

mkdir -p "$BACKUP" "$PANEL_DIR/public/themes/zypehost"
cp -a "$WRAPPER" "$BACKUP/wrapper.blade.php"
[[ -f "$PANEL_DIR/.env" ]] && cp -a "$PANEL_DIR/.env" "$BACKUP/.env"

cp -f "$SRC/branding.css" "$PANEL_DIR/public/themes/zypehost/branding.css"
cp -f "$SRC/branding.js" "$PANEL_DIR/public/themes/zypehost/branding.js"
cp -f "$SRC/admin.css" "$PANEL_DIR/public/themes/zypehost/admin.css"
cp -f "$SRC/zypehost.svg" "$PANEL_DIR/public/themes/zypehost/zypehost.svg"
cp -f "$SRC/background.jpeg" "$PANEL_DIR/public/themes/zypehost/background.jpeg"

python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
marker = 'ZYPEHOST_V4_ASSETS'
block = '''<!-- ZYPEHOST_V4_ASSETS -->\n<link rel="icon" type="image/svg+xml" href="{{ asset('themes/zypehost/zypehost.svg') }}">\n<link rel="stylesheet" href="{{ asset('themes/zypehost/branding.css') }}">\n<script defer src="{{ asset('themes/zypehost/branding.js') }}"></script>\n<!-- /ZYPEHOST_V4_ASSETS -->\n'''
if marker not in s:
    if '</head>' in s:
        s = s.replace('</head>', block + '</head>', 1)
    elif '</body>' in s:
        s = s.replace('</body>', block + '</body>', 1)
    else:
        raise SystemExit('Kein </head> oder </body> gefunden')
else:
    import re
    s = re.sub(r'<!-- ZYPEHOST_V4_ASSETS -->.*?<!-- /ZYPEHOST_V4_ASSETS -->\n?', block, s, flags=re.S)
p.write_text(s, encoding='utf-8')
PY

if [[ -f "$PANEL_DIR/.env" ]]; then
  if grep -q '^APP_NAME=' "$PANEL_DIR/.env"; then
    sed -i -E 's/^APP_NAME=.*/APP_NAME=ZypeHost/' "$PANEL_DIR/.env"
  else
    printf '\nAPP_NAME=ZypeHost\n' >> "$PANEL_DIR/.env"
  fi
fi

cd "$PANEL_DIR"
php artisan optimize:clear >/dev/null
php artisan view:clear >/dev/null || true
if id www-data >/dev/null 2>&1; then
  chown -R www-data:www-data "$PANEL_DIR/public/themes/zypehost"
fi

printf '\n'
printf '%s\n' '=============================================='
printf '%s\n' ' ZypeHost Pterodactyl Theme v4 installiert'
printf '%s\n' ' Login: Referenz-Layout + dein ZypeHost Logo'
printf '%s\n' ' Hintergrund: digitales Grid (background.jpeg)'
printf '%s\n' ' Footer: Impressum | Rechte + Copyright ZypeHost 26/27 ©️'
printf '%s\n' " Backup: $BACKUP"
printf '%s\n' '=============================================='
printf '\n'
printf '%s\n' 'Hinweis: Trag deine echten Impressumsdaten in'
printf '%s\n' 'branding.js unter LEGAL.impressum ein.'
