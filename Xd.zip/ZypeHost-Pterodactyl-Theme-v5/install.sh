#!/usr/bin/env bash
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="$ROOT_DIR/theme/public/themes/zypehost"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$PANEL_DIR/storage/zypehost-backups/v5-$STAMP"
TARGET="$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"

fail(){ echo "[ZypeHost v5] ERROR: $*" >&2; exit 1; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"
[[ -f "$TARGET" ]] || fail "LoginFormContainer.tsx nicht gefunden: $TARGET"
[[ -f "$SRC/background.jpeg" ]] || fail "background.jpeg fehlt"
[[ -f "$SRC/zypehost-logo.png" ]] || fail "zypehost-logo.png fehlt"

mkdir -p "$BACKUP" "$PANEL_DIR/public/themes/zypehost"
cp -a "$TARGET" "$BACKUP/LoginFormContainer.tsx"
[[ -f "$WRAPPER" ]] && cp -a "$WRAPPER" "$BACKUP/wrapper.blade.php" || true
[[ -f "$PANEL_DIR/.env" ]] && cp -a "$PANEL_DIR/.env" "$BACKUP/.env" || true

# Remove the previous v4 CSS/JS injection if it exists. The v5 theme is a real React component
# so it does not depend on DOM mutation after render.
if [[ -f "$WRAPPER" ]]; then
  python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
for marker in ('ZYPEHOST_V4_ASSETS','ZYPEHOST_V3_ASSETS'):
    s = re.sub(r'<!--\s*'+re.escape(marker)+r'\s*-->.*?<!--\s*/'+re.escape(marker)+r'\s*-->\s*', '', s, flags=re.S)
p.write_text(s, encoding='utf-8')
PY
fi

cp -f "$SRC/background.jpeg" "$PANEL_DIR/public/themes/zypehost/background.jpeg"
cp -f "$SRC/zypehost-logo.png" "$PANEL_DIR/public/themes/zypehost/zypehost-logo.png"

cat > "$TARGET" <<'TSX'
import React, { forwardRef, useState } from 'react';
import { Form } from 'formik';
import styled from 'styled-components/macro';
import FlashMessageRender from '@/components/FlashMessageRender';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const Page = styled.main`
    position: fixed;
    inset: 0;
    z-index: 1000;
    width: 100vw;
    min-height: 100dvh;
    overflow-y: auto;
    overflow-x: hidden;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 36px 22px 22px;
    background:
        linear-gradient(180deg, rgba(1, 9, 13, 0.36), rgba(1, 7, 11, 0.82)),
        url('/themes/zypehost/background.jpeg') center center / cover no-repeat;
    isolation: isolate;

    &::before {
        content: '';
        position: fixed;
        inset: 0;
        z-index: -1;
        pointer-events: none;
        background:
            radial-gradient(circle at 50% 35%, rgba(0, 213, 255, 0.11), transparent 34%),
            radial-gradient(circle at 15% 80%, rgba(0, 150, 255, 0.08), transparent 30%),
            radial-gradient(circle at 88% 16%, rgba(255, 45, 65, 0.05), transparent 22%);
    }
`;

const TitleBlock = styled.div`
    width: min(980px, 100%);
    margin-bottom: 18px;
    text-align: center;
    color: #fff;
`;

const BrandMark = styled.div`
    display: inline-flex;
    align-items: center;
    gap: 9px;
    margin-bottom: 10px;
    padding: 7px 12px;
    border: 1px solid rgba(255,255,255,.18);
    border-radius: 999px;
    background: rgba(0, 0, 0, .20);
    box-shadow: 0 10px 30px rgba(0,0,0,.16);
    backdrop-filter: blur(14px);
    color: rgba(255,255,255,.9);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .2em;
    text-transform: uppercase;

    span {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #00d9ff;
        box-shadow: 0 0 14px rgba(0,217,255,.85);
    }
`;

const Title = styled.h1`
    margin: 0;
    color: #fff;
    font-size: clamp(28px, 4vw, 38px);
    line-height: 1.08;
    font-weight: 800;
    letter-spacing: -.035em;
    text-shadow: 0 8px 28px rgba(0,0,0,.36);
`;

const Subtitle = styled.p`
    margin: 10px auto 0;
    max-width: 620px;
    color: rgba(255,255,255,.70);
    font-size: 13px;
    line-height: 1.6;
`;

const Card = styled.section`
    width: min(960px, 100%);
    display: grid;
    grid-template-columns: minmax(280px, 39%) minmax(0, 1fr);
    overflow: hidden;
    border: 1px solid rgba(255,255,255,.54);
    border-radius: 20px;
    background: rgba(255,255,255,.97);
    box-shadow:
        0 34px 100px rgba(0,0,0,.52),
        0 10px 30px rgba(0,0,0,.18);
    backdrop-filter: blur(18px);

    @media (max-width: 760px) {
        grid-template-columns: 1fr;
        border-radius: 16px;
    }
`;

const LogoPane = styled.div`
    position: relative;
    min-height: 430px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 34px;
    box-sizing: border-box;
    background:
        radial-gradient(circle at 50% 45%, rgba(255,255,255,1), rgba(248,250,253,1) 64%, rgba(239,244,249,1));
    border-right: 1px solid #e2e8ef;

    &::before {
        content: '';
        position: absolute;
        inset: 28px;
        border: 2px solid rgba(210, 31, 43, .82);
        border-radius: 12px;
        box-shadow:
            inset 0 0 0 1px rgba(210,31,43,.08),
            0 0 30px rgba(210,31,43,.08);
        pointer-events: none;
    }

    &::after {
        content: 'ZypeHost';
        position: absolute;
        left: 50%;
        bottom: 24px;
        transform: translateX(-50%);
        color: #8896a6;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: .34em;
        text-transform: uppercase;
    }

    img {
        position: relative;
        z-index: 1;
        display: block;
        width: min(225px, 82%);
        max-height: 300px;
        object-fit: contain;
        filter: drop-shadow(0 16px 24px rgba(35, 50, 65, .18));
    }

    @media (max-width: 760px) {
        min-height: 290px;
        border-right: 0;
        border-bottom: 1px solid #e2e8ef;
        padding: 24px;

        &::before { inset: 18px; }
        img { width: 180px; max-height: 220px; }
        &::after { bottom: 14px; }
    }
`;

const FormPane = styled.div`
    min-width: 0;
    padding: 42px 44px 36px;
    box-sizing: border-box;

    @media (max-width: 760px) {
        padding: 28px 22px 24px;
    }
`;

const FormHeading = styled.div`
    margin-bottom: 26px;

    h2 {
        margin: 0;
        color: #15283b;
        font-size: 26px;
        line-height: 1.2;
        font-weight: 800;
        letter-spacing: -.02em;
    }

    p {
        margin: 7px 0 0;
        color: #748394;
        font-size: 13px;
        line-height: 1.6;
    }
`;

const StyledForm = styled(Form)`
    width: 100%;

    label,
    label span,
    .input-label {
        color: #526a80 !important;
        font-size: 11px !important;
        font-weight: 800 !important;
        letter-spacing: .12em !important;
        text-transform: uppercase;
    }

    input,
    textarea,
    select {
        width: 100% !important;
        min-height: 52px;
        box-sizing: border-box;
        border: 1px solid #d1d9e2 !important;
        border-radius: 10px !important;
        background: #fff !important;
        color: #182a3b !important;
        box-shadow: 0 2px 9px rgba(22, 41, 57, .035) !important;
        transition: border-color .16s ease, box-shadow .16s ease, transform .16s ease;
    }

    input:hover,
    textarea:hover,
    select:hover {
        border-color: #b7c4d1 !important;
    }

    input:focus,
    textarea:focus,
    select:focus {
        border-color: #1268d8 !important;
        box-shadow: 0 0 0 3px rgba(18,104,216,.11) !important;
        outline: 0 !important;
    }

    input::placeholder {
        color: #a3afbb !important;
    }

    button[type='submit'] {
        width: 100% !important;
        min-height: 56px;
        margin-top: 2px;
        border: 0 !important;
        border-radius: 10px !important;
        background: linear-gradient(135deg, #1674e6, #0b5ec6) !important;
        color: #fff !important;
        font-weight: 800 !important;
        letter-spacing: .08em;
        text-transform: uppercase;
        box-shadow: 0 12px 24px rgba(18,104,216,.24) !important;
        transition: transform .16s ease, box-shadow .16s ease, filter .16s ease;
    }

    button[type='submit']:hover {
        transform: translateY(-1px);
        filter: brightness(1.03);
        box-shadow: 0 16px 28px rgba(18,104,216,.29) !important;
    }

    button[type='submit']:active {
        transform: translateY(0);
    }

    a {
        color: #60758a !important;
        font-size: 11px !important;
        font-weight: 800 !important;
        letter-spacing: .10em !important;
        text-transform: uppercase;
        text-decoration: none !important;
    }

    a:hover {
        color: #1268d8 !important;
    }
`;

const AlertWrap = styled.div`
    margin-bottom: 16px;

    [role='alert'] {
        border-radius: 10px !important;
    }
`;

const Footer = styled.footer`
    width: min(960px, 100%);
    box-sizing: border-box;
    padding: 18px 0 2px;
    text-align: center;
    color: rgba(255,255,255,.74);
    font-size: 11px;
`;

const FooterButtons = styled.div`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-wrap: wrap;

    button {
        appearance: none;
        border: 1px solid rgba(255,255,255,.24);
        border-radius: 999px;
        padding: 8px 15px;
        background: rgba(0,0,0,.18);
        color: rgba(255,255,255,.88);
        cursor: pointer;
        font: inherit;
        font-weight: 700;
        letter-spacing: .04em;
        backdrop-filter: blur(10px);
        transition: background .16s ease, border-color .16s ease, transform .16s ease;
    }

    button:hover {
        background: rgba(15, 119, 212, .42);
        border-color: rgba(255,255,255,.44);
        transform: translateY(-1px);
    }
`;

const Copyright = styled.div`
    margin-top: 9px;
    color: rgba(255,255,255,.54);
    letter-spacing: .03em;
`;

const ModalOverlay = styled.div`
    position: fixed;
    inset: 0;
    z-index: 2000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 22px;
    box-sizing: border-box;
    background: rgba(0, 7, 12, .72);
    backdrop-filter: blur(9px);
`;

const Modal = styled.div`
    width: min(720px, 100%);
    max-height: min(80vh, 760px);
    overflow: auto;
    border: 1px solid rgba(255,255,255,.58);
    border-radius: 16px;
    background: rgba(255,255,255,.98);
    color: #24384b;
    box-shadow: 0 36px 100px rgba(0,0,0,.48);
`;

const ModalHeader = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    padding: 18px 20px;
    border-bottom: 1px solid #e7edf3;

    h2 {
        margin: 0;
        color: #142b40;
        font-size: 21px;
        font-weight: 800;
    }

    button {
        width: 34px;
        height: 34px;
        border: 0;
        border-radius: 9px;
        background: #eef3f7;
        color: #5c6f80;
        cursor: pointer;
        font-size: 23px;
        line-height: 1;
    }
`;

const ModalBody = styled.div`
    padding: 22px;
    font-size: 14px;
    line-height: 1.7;

    h3 {
        margin: 0 0 8px;
        color: #19344e;
        font-size: 17px;
    }

    p { margin: 0 0 14px; }
`;

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => {
    const [modal, setModal] = useState<'impressum' | 'rechte' | null>(null);

    const closeModal = () => setModal(null);

    return (
        <Page>
            <TitleBlock>
                <BrandMark><span /> ZypeHost</BrandMark>
                <Title>{title || 'Login to Continue'}</Title>
                <Subtitle>Secure access to your hosting control panel.</Subtitle>
            </TitleBlock>

            <Card>
                <LogoPane>
                    <img src={'/themes/zypehost/zypehost-logo.png'} alt={'ZypeHost'} />
                </LogoPane>

                <FormPane>
                    <FormHeading>
                        <h2>Welcome back</h2>
                        <p>Sign in with your ZypeHost account to continue.</p>
                    </FormHeading>

                    <AlertWrap>
                        <FlashMessageRender />
                    </AlertWrap>

                    <StyledForm {...props} ref={ref}>
                        {props.children}
                    </StyledForm>
                </FormPane>
            </Card>

            <Footer>
                <FooterButtons>
                    <button type={'button'} onClick={() => setModal('impressum')}>Impressum</button>
                    <button type={'button'} onClick={() => setModal('rechte')}>Rechte</button>
                </FooterButtons>
                <Copyright>Copyright ZypeHost 26/27 ©️</Copyright>
            </Footer>

            {modal && (
                <ModalOverlay onMouseDown={closeModal}>
                    <Modal onMouseDown={(event) => event.stopPropagation()}>
                        <ModalHeader>
                            <h2>{modal === 'impressum' ? 'Impressum' : 'Rechte'}</h2>
                            <button type={'button'} aria-label={'Close'} onClick={closeModal}>×</button>
                        </ModalHeader>
                        <ModalBody>
                            {modal === 'impressum' ? (
                                <>
                                    <h3>ZypeHost</h3>
                                    <p><strong>Betreiber:</strong><br />HIER DEINEN NAMEN / FIRMA EINTRAGEN</p>
                                    <p><strong>Adresse:</strong><br />HIER STRASSE, PLZ UND ORT EINTRAGEN</p>
                                    <p><strong>E-Mail:</strong><br />HIER E-MAIL-ADRESSE EINTRAGEN</p>
                                </>
                            ) : (
                                <>
                                    <h3>ZypeHost</h3>
                                    <p>Informationen zu Marken, Grafiken und eigenen Inhalten von ZypeHost werden hier veröffentlicht.</p>
                                    <p>Pterodactyl ist ein eigenständiges Open-Source-Projekt. Diese Login-Darstellung ist ein eigenes ZypeHost-Branding.</p>
                                    <p>Drittanbieter-Inhalte bleiben ihren jeweiligen Rechteinhabern zugeordnet.</p>
                                </>
                            )}
                        </ModalBody>
                    </Modal>
                </ModalOverlay>
            )}
        </Page>
    );
});
TSX

cat > /mnt/data/zypehost-v5-build/ZypeHost-Pterodactyl-Theme-v5/README.md <<'EOF'
# ZypeHost Pterodactyl Theme v5

Premium ZypeHost login redesign for Pterodactyl.

- Full-screen supplied digital-grid background
- Supplied ZypeHost character logo from the reference image
- Premium white split-card layout
- Responsive mobile layout
- Blue gradient login button
- Impressum and Rechte modals
- Copyright: ZypeHost 26/27 ©️
- v4 DOM-injection assets are removed from the wrapper to avoid conflicts
- Installer creates a timestamped backup before changing the panel

## Install from GitHub

```bash
cd /root && rm -rf ZypeHost-Pterodactyl-Theme && git clone https://github.com/infojobwahl-rgb/gihib.git ZypeHost-Pterodactyl-Theme && cd ZypeHost-Pterodactyl-Theme && unzip -o "$(find . -maxdepth 2 -type f -name '*.zip' | head -n1)" && cd ZypeHost-Pterodactyl-Theme-v5 && chmod +x install.sh && bash install.sh
```

After installation, the frontend must be rebuilt with `yarn build:production` because Pterodactyl's frontend is React-based.
