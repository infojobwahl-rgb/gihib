ZypeHost Pterodactyl Theme v5 assets.
background.jpeg = full-screen digital-grid background.
zypehost-logo.png = ZypeHost logo cropped from the supplied reference image.
